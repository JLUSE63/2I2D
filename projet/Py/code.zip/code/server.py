import requests as rq

def sendData(link = "http://localhost/site/cours/site/projet/pages/add.php"):
  r = rq.get(link)

  return r.text