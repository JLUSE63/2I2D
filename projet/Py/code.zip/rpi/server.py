import requests as rq
r = rq.get("http://localhost/site/cours/site/projet/pages/add.php")
page = r.text

print(page)